import { motion } from "framer-motion"

export default function Header() {
  return (
    <header className="bg-gradient-to-r from-blue-600 to-purple-600 text-white py-20 text-center relative overflow-hidden">
      <div className="absolute inset-0 opacity-20">
        <div className="absolute inset-0 bg-[url('/circuit-pattern.svg')] bg-repeat"></div>
      </div>
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="relative z-10"
      >
        <h1 className="text-5xl font-bold mb-4">Suvankar Dash</h1>
        <p className="text-2xl">Data Scientist & IoT Visionary</p>
        <p className="text-xl mt-2">Bhubaneswar, Odisha</p>
      </motion.div>
    </header>
  )
}

