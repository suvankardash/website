import { motion } from 'framer-motion'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

const educations = [
  {
    school: "St. Teresa's School",
    location: "Joda, Odisha",
    period: "2006-19",
    marks: "91%",
    description: "Completed high school with a focus on science subjects, achieving a strong academic record and participating in various co-curricular activities."
  },
  {
    school: "Aakash Educational Services",
    location: "Bhubaneswar, Odisha",
    period: "2019-21",
    marks: "",
    description: "Graduated in science stream, specializing in physics, chemistry, and mathematics. Actively engaged in science fairs and group projects."
  },
  {
    school: "Gauri Shankar R.E.M. School",
    location: "Bhubaneswar, Odisha",
    period: "2019-21",
    marks: "91.8%",
    description: "Graduated in science stream, specializing in physics, chemistry, and mathematics. Actively engaged in science fairs and group projects."
  },
  {
    school: "Kalinga Institute of Industrial Technology (KIIT) Deemed to be University",
    location: "Bhubaneswar, Odisha",
    period: "2021-25",
    marks: "7.4 CGPA",
    description: "Currently pursuing a degree in Computer Science and Engineering, focusing on cutting-edge technologies and practical applications."
  }
]

export default function Education() {
  return (
    <section id="education" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <motion.h2
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-4xl font-bold text-center mb-12 text-blue-600"
        >
          Education
        </motion.h2>
        <div className="grid md:grid-cols-2 gap-8">
          {educations.map((edu, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle>{edu.school}</CardTitle>
                  <CardDescription>{edu.location}</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-500 mb-2">{edu.period} {edu.marks && `• ${edu.marks}`}</p>
                  <p className="text-gray-700">{edu.description}</p>
                </CardContent>
                <CardFooter>
                  <Button asChild>
                    <a href="https://drive.google.com/file/d/1gjOXd5L99g1AVIfPEJYHGEdYeDQb1bkC/view?usp=drive_link" target="_blank" rel="noopener noreferrer">View Transcript</a>
                  </Button>
                </CardFooter>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

