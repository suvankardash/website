import { motion } from 'framer-motion'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

const projects = [
  {
    title: "Dynamic Traffic Flow Management",
    description: "Designed and implemented a real-time traffic management system to improve urban mobility and prioritize emergency response. The system integrates YOLOv8 for real-time vehicle detection and EasyOCR for license plate recognition, ensuring efficient traffic monitoring.",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/intro_dtfm.jpg-sdOe4S7dDxhv2pYR5V7OjeUyl9I2OU.jpeg",
    link: "https://drive.google.com/file/d/1gjOXd5L99g1AVIfPEJYHGEdYeDQb1bkC/view?usp=drive_link"
  },
  {
    title: "Sales Analysis",
    description: "Performed an in-depth analysis of sales and profit trends for Tata Steel's vendor using Tableau to create interactive dashboards. This project highlighted patterns in product performance, regional sales, and seasonal fluctuations, providing actionable insights to enhance business strategies.",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/intro_sa.jpg-Ddj3on747OXPPlc50der8lP4RWuQCp.png",
    link: "https://medium.com/@suvankardash0103/0c3a000ea112"
  },
  {
    title: "Flight Delay Prediction",
    description: "Developed a machine learning model to predict flight delays based on historical data and various factors such as weather conditions, airline performance, and airport congestion.",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Designer-AdFmc4mMCLhZAlC9gaTmaOxiioDFu0.jpeg",
    link: "#"
  }
]

export default function Projects() {
  return (
    <section id="projects" className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <motion.h2
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-4xl font-bold text-center mb-12 text-blue-600"
        >
          Projects
        </motion.h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card className="h-full flex flex-col">
                <CardHeader>
                  <CardTitle>{project.title}</CardTitle>
                </CardHeader>
                <CardContent className="flex-grow">
                  <div className="aspect-video mb-4 overflow-hidden rounded-md">
                    <img 
                      src={project.image} 
                      alt={project.title} 
                      className="w-full h-full object-cover transform hover:scale-105 transition-transform duration-300" 
                    />
                  </div>
                  <CardDescription>{project.description}</CardDescription>
                </CardContent>
                <CardFooter>
                  <Button asChild className="w-full">
                    <a href={project.link} target="_blank" rel="noopener noreferrer">View Project</a>
                  </Button>
                </CardFooter>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

