import { motion } from 'framer-motion'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

const certifications = [
  {
    title: "AWS Academy Graduate - AWS Cloud Foundations",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/AWS_Cert-wxT7L7A83mReKoX05Uh9jAFhTExCEO.png",
    date: "February 2024"
  },
  {
    title: "Generative AI for Educators",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/genai_educators-5DKrm4dpm0LCwLJIDA5wBldFtmlmWD.png",
    date: "September 2024"
  },
  {
    title: "Deep Learning with PyTorch: GANs",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/dl_gans-dPZWOOvGhaI4GOFIA5NcU3DK1ZWVl5.png",
    date: "June 2024"
  },
  {
    title: "Machine Learning Specialization",
    image: "/ml_speclztn.png",
    date: "May 2024"
  },
  {
    title: "Google Project Management Certificate",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/project_mngmt-4n2ccfs53AUEin3JKX13lV48AxSOd3.png",
    date: "March 2024"
  },
  {
    title: "IBM Project Management Fundamentals",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/proj_mngmt_ibm-L0GzUsvPRwFQ8Cb6HLSCVpXxKsBlCN.png",
    date: "February 2024"
  }
]

export default function Certifications() {
  return (
    <section id="certifications" className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <motion.h2
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-4xl font-bold text-center mb-12 text-blue-600"
        >
          Certifications
        </motion.h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {certifications.map((cert, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card className="h-full flex flex-col">
                <CardHeader>
                  <CardTitle>{cert.title}</CardTitle>
                  <CardDescription>{cert.date}</CardDescription>
                </CardHeader>
                <CardContent className="flex-grow flex items-center justify-center p-6">
                  <img 
                    src={cert.image} 
                    alt={cert.title} 
                    className="max-w-full max-h-48 object-contain rounded-lg shadow-sm" 
                  />
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

