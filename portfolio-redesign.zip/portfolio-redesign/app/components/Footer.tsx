import { Twitter, Linkedin, Github, Mail, FileText } from 'lucide-react'

export default function Footer() {
  return (
    <footer className="bg-gray-800 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="text-center mb-8">
          <p className="text-lg font-semibold">&copy; 2024 Suvankar Dash | Developed by Suvankar Dash</p>
        </div>
        <div className="flex justify-center space-x-8 mb-8">
          <a href="https://x.com/suvankar_dash01" target="_blank" rel="noopener noreferrer" className="hover:text-blue-400 transition-colors duration-300">
            <Twitter size={28} />
          </a>
          <a href="https://www.linkedin.com/in/suvankar-dash-37a89b247/" target="_blank" rel="noopener noreferrer" className="hover:text-blue-600 transition-colors duration-300">
            <Linkedin size={28} />
          </a>
          <a href="https://github.com/suvankardash" target="_blank" rel="noopener noreferrer" className="hover:text-gray-400 transition-colors duration-300">
            <Github size={28} />
          </a>
          <a href="mailto:suvankardash0103@gmail.com" className="hover:text-red-400 transition-colors duration-300">
            <Mail size={28} />
          </a>
          <a href="https://www.hackerrank.com/profile/suvankar_dash01" target="_blank" rel="noopener noreferrer" className="hover:text-green-400 transition-colors duration-300">
            <FileText size={28} />
          </a>
          <a href="https://medium.com/@suvankardash0103" target="_blank" rel="noopener noreferrer" className="hover:text-gray-400 transition-colors duration-300">
            <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="currentColor">
              <path d="M13.54 12a6.8 6.8 0 01-6.77 6.82A6.8 6.8 0 010 12a6.8 6.8 0 016.77-6.82A6.8 6.8 0 0113.54 12zM20.96 12c0 3.54-1.51 6.42-3.38 6.42-1.87 0-3.39-2.88-3.39-6.42s1.52-6.42 3.39-6.42 3.38 2.88 3.38 6.42M24 12c0 3.17-.53 5.75-1.19 5.75-.66 0-1.19-2.58-1.19-5.75s.53-5.75 1.19-5.75C23.47 6.25 24 8.83 24 12z"/>
            </svg>
          </a>
        </div>
        <div className="text-center">
          <p className="flex items-center justify-center text-lg">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-2" viewBox="0 0 20 20" fill="currentColor">
              <path d="M2 3a1 1 0 011-1h2.153a1 1 0 01.986.836l.74 4.435a1 1 0 01-.54 1.06l-1.548.773a11.037 11.037 0 006.105 6.105l.774-1.548a1 1 0 011.059-.54l4.435.74a1 1 0 01.836.986V17a1 1 0 01-1 1h-2C7.82 18 2 12.18 2 5V3z" />
            </svg>
            +91 7854887837
          </p>
        </div>
      </div>
    </footer>
  )
}

