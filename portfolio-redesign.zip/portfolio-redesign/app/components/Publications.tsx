import { motion } from 'framer-motion'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function Publications() {
  return (
    <section id="publications" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <motion.h2
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-4xl font-bold text-center mb-12 text-blue-600"
        >
          Publications
        </motion.h2>
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Card>
            <CardHeader>
              <CardTitle>Dynamic Traffic Flow Management</CardTitle>
              <CardDescription>Published in IEEE</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col md:flex-row gap-6">
                <img src="/intro_dtfm.jpg" alt="Dynamic Traffic Flow Management" className="w-full md:w-1/3 h-auto rounded-lg" />
                <div>
                  <p className="text-gray-700 mb-4">
                    Designed and implemented a real-time traffic management system to improve urban mobility and prioritize emergency response. The system integrates YOLOv8 for real-time vehicle detection and EasyOCR for license plate recognition, ensuring efficient traffic monitoring.
                  </p>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button asChild>
                <a href="https://drive.google.com/file/d/1gjOXd5L99g1AVIfPEJYHGEdYeDQb1bkC/view?usp=drive_link" target="_blank" rel="noopener noreferrer">View Publication</a>
              </Button>
              <Button variant="outline" asChild>
                <a href="#" target="_blank" rel="noopener noreferrer">Cite It</a>
              </Button>
            </CardFooter>
          </Card>
        </motion.div>
      </div>
    </section>
  )
}

