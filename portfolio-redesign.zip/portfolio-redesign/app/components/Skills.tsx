import { motion } from 'framer-motion'

const technicalSkills = [
  { 
    name: 'Python', 
    logo: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/python.jpg-z184S72Iea5fhhVVrM0u2euHmRff4g.jpeg'
  },
  { 
    name: 'Visual Studio Code', 
    logo: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/vsc-zPbksrq90UgF67QDO4tgcS0yyjzyXl.jpeg'
  },
  { 
    name: 'Tableau', 
    logo: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/tableau.jpg-ES44vhoeC13lZ3GtUb0qmFFKC9W9Rw.jpeg'
  },
  { 
    name: 'Java', 
    logo: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/java.jpg-7tKqdqOXJM7RhBZtzYOkBzx3Wdrhwk.jpeg'
  },
  { 
    name: 'MySQL', 
    logo: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/mysql.jpg-n1fi2FNHEWqf0YcCplLjPGaKMZp7To.jpeg'
  },
  { 
    name: 'Oracle DB', 
    logo: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/oracledb.jpg-a6V6okIimlaMK7wNE0FBarKieH7Oeb.jpeg'
  },
  { 
    name: 'MongoDB', 
    logo: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/mongodb.jpg-12Jd3caqcNnmQJ4BdCilQjZhj6MS1S.jpeg'
  },
  { 
    name: 'Machine Learning', 
    logo: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/ml.jpg-jgwvpgUWPI1ro6hWr3i5LV97P3eUG0.jpeg'
  },
  { 
    name: 'Power BI', 
    logo: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/powerbi.jpg-lmCfZ5Dwd2L4Nov6lf15jkiPZ053nP.jpeg'
  },
  { 
    name: 'AWS Cloud', 
    logo: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/aws-HFfHnAR6bwzgwNB04hNWAxX5M8qtR3.png'
  },
  { 
    name: 'C/C++', 
    logo: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/c-Kcjozt84TtKNzsbhdpMk3xbkcMauAN.jpeg'
  },
  { 
    name: 'GitHub', 
    logo: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/github-2EptO93PCX4ErFa1UyUT990IW9oNfa.png'
  }
]

const nonTechnicalSkills = [
  { 
    name: 'Badminton', 
    logo: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/badminton-J33oeO6L0mjcV8kXn22Vvxb4h3PGj4.jpeg'
  },
  { 
    name: 'Binging', 
    logo: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/binge-BTkqZAclADjLioVh5YAks08WqBg54a.jpeg'
  },
  { 
    name: 'Travelling', 
    logo: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/travelling-4FGHYnKAtTthXMAfss6YBm67mQWGd0.jpeg'
  }
]

export default function Skills() {
  return (
    <section id="skills" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <motion.h2
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-4xl font-bold text-center mb-12 text-blue-600"
        >
          Skills
        </motion.h2>
        <div className="mb-12">
          <h3 className="text-2xl font-semibold mb-6 text-gray-800">Technical Skills</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-6">
            {technicalSkills.map((skill, index) => (
              <motion.div
                key={skill.name}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-white rounded-lg shadow-md p-4 flex flex-col items-center hover:shadow-lg transition-shadow duration-300"
              >
                <div className="w-16 h-16 flex items-center justify-center mb-4">
                  <img src={skill.logo} alt={skill.name} className="max-w-full max-h-full object-contain" />
                </div>
                <p className="text-center font-medium">{skill.name}</p>
              </motion.div>
            ))}
          </div>
        </div>
        <div>
          <h3 className="text-2xl font-semibold mb-6 text-gray-800">Non-Technical Skills</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-6">
            {nonTechnicalSkills.map((skill, index) => (
              <motion.div
                key={skill.name}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-white rounded-lg shadow-md p-4 flex flex-col items-center hover:shadow-lg transition-shadow duration-300"
              >
                <div className="w-16 h-16 flex items-center justify-center mb-4">
                  <img src={skill.logo} alt={skill.name} className="max-w-full max-h-full object-contain" />
                </div>
                <p className="text-center font-medium">{skill.name}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

