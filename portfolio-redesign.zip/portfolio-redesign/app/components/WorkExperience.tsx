import { motion } from 'framer-motion'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

const experiences = [
  {
    company: "Tata Steel LTD.",
    role: "Data Analytics Intern",
    duration: "May 2024 - August 2024",
    description: "Introduction to Data Analytics and Tableau and its implementation in a live project. Had an impactful contribution to the live analytics project. Done a small project related to Tableau Analytics project related to sales of a superstore for furniture and electronics items supply.",
    logo: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/tata.jpg-TOwEyV98SedtaWOTIJHSP52VqqupDF.jpeg"
  },
  {
    company: "Tata Steel LTD.",
    role: "Data Science Intern",
    duration: "May 2023 - June 2023",
    description: "Introduction to Data Science and Python and its implementation in a live project. Had an impactful contribution to project in kick-starting it and also put my software engineering studies and practices related to our work in data science field for developing my data science project.",
    logo: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/tata.jpg-TOwEyV98SedtaWOTIJHSP52VqqupDF.jpeg"
  },
  {
    company: "IoT Lab, KIIT",
    role: "IoT Developer",
    duration: "Sept 2022 - Sept 2024",
    description: "Developed leadership skills by leading teams for three consecutive projects, earning the 'Best Team Performance' award. Innovated IoT solutions to enhance communication in township areas, including a smart parking system for automated fee deductions.",
    logo: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/iotlab.jpg-ny2P3to5j1hxlObEaCqICXF8ZvElx9.jpeg"
  },
  {
    company: "Forage Inc.",
    role: "Virtual Internships",
    duration: "August 2022 - August 2024",
    description: "Participated in various virtual internship programs, gaining hands-on experience in different areas of technology and business.",
    logo: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/forage-bI5REd2MIIzgAm13IcE12ZRz3ZF4MG.png"
  }
]

export default function WorkExperience() {
  return (
    <section id="work-experience" className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <motion.h2
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-4xl font-bold text-center mb-12 text-blue-600"
        >
          Work Experience
        </motion.h2>
        <div className="grid md:grid-cols-2 gap-8">
          {experiences.map((exp, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card className="h-full flex flex-col">
                <CardHeader>
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 flex items-center justify-center">
                      <img src={exp.logo} alt={exp.company} className="max-w-full max-h-full object-contain" />
                    </div>
                    <div>
                      <CardTitle>{exp.company}</CardTitle>
                      <CardDescription>{exp.role}</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-500 mb-2">{exp.duration}</p>
                  <p className="text-gray-700">{exp.description}</p>
                </CardContent>
                <CardFooter>
                  <Button asChild>
                    <a href="#" target="_blank" rel="noopener noreferrer">View Project</a>
                  </Button>
                </CardFooter>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

