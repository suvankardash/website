import { motion } from 'framer-motion'

export default function About() {
  return (
    <section id="about" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <motion.h2
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-4xl font-bold text-center mb-8 text-blue-600"
        >
          About Myself
        </motion.h2>
        <div className="max-w-3xl mx-auto">
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-xl font-semibold text-gray-800 mb-6"
          >
            Hi there! I'm <span className="text-purple-600">Suvankar Dash</span>, a <strong className="text-blue-600">trailblazing Data Scientist</strong> and <strong className="text-green-600">IoT Visionary</strong> from the dynamic city of Bhubaneswar, India.
          </motion.p>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="text-gray-700 mb-6"
          >
            With a robust foundation in <strong>Machine Learning</strong>, <strong>IoT</strong>, and <strong>Data Analytics</strong>, I am driven by the challenge of solving real-world problems through the power of technology. My professional journey reflects a relentless pursuit of excellence and a passion for creating value-driven solutions.
          </motion.p>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.6 }}
            className="text-gray-700 mb-6"
          >
            During my tenure at <strong>Tata Steel</strong> as a <em>Data Science Intern</em>, I spearheaded analytical projects that informed critical business strategies. At <strong>IoT Lab, KIIT</strong>, I led cutting-edge projects such as smart parking systems and advanced weather station setups, earning accolades for my ability to innovate and execute.
          </motion.p>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.8 }}
            className="text-2xl italic text-center text-blue-600 font-semibold"
          >
            "Let's innovate, inspire, and create a smarter future together."
          </motion.p>
        </div>
      </div>
    </section>
  )
}

