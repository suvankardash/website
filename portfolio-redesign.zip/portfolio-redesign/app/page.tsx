import Header from './components/Header'
import Navbar from './components/Navbar'
import About from './components/About'
import Featured from './components/Featured'
import Skills from './components/Skills'
import Projects from './components/Projects'
import Publications from './components/Publications'
import WorkExperience from './components/WorkExperience'
import Education from './components/Education'
import Certifications from './components/Certifications'
import Contact from './components/Contact'
import Footer from './components/Footer'

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <Header />
      <Navbar />
      <main className="container mx-auto px-4 py-8">
        <About />
        <Featured />
        <Skills />
        <Projects />
        <Publications />
        <WorkExperience />
        <Education />
        <Certifications />
        <Contact />
      </main>
      <Footer />
    </div>
  )
}

